# Daughters of Lust 0.4

## Localization

* Added Korean localization. Thanks AKTKNGS!

## Compatibility

* Now works with Royal Court update.

## Tweaks

* Added icons to game rules.