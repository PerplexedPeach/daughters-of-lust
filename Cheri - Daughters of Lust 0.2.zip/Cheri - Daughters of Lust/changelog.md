# Daughters of Lust 0.2

## Localization

* Added French translation,  thanks Triskelia
* Added Simplified Chinese translation, thanks lonelyneet