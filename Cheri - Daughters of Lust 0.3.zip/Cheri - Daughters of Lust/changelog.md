# Daughters of Lust 0.3

## Compatibility

* Updated for compatibility with Carnalitas 1.5.

## Localization

* Added Spanish translation,  thanks Kalvis