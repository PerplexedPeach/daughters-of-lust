# Daughters of Lust

Daughters of Lust is a mod that adds succubi to Crusader Kings 3.

# Goals

- Be hot as fuck
- Create interesting gameplay
- Enable "awesome slut" fantasy
- Enable "Lady Macbeth" fantasy
- Enable "succubus hunter" fantasy

# Todo

- Sexual Power abilities
- Withdrawal
- Suspicion
- Depose Succubus CB
- Changing identities to avoid Suspicion
- interesting succubus AI events

# Completed Abilities

- 1: Drain Life (Inflict major health penalty on someone after sleeping with them)
- 5: Fascinate (Single target opinion increase)
- 10: Mesmerize (Gain Weak Hook on someone after sleeping with them)
- 15: Alter Self (Change own beauty, body part size)
- 20: Alter Sexuality (Sexuality change on target)
- 25: Regenerate (Cure wounds/disfigurements)
- 30: Torment (Increase Stress on target)

# Todo Abilities

- 35: Inspire (Give someone a stat boost after sleeping with them)
- 40: Incite Rivalry (Make two targets become rivals)
- 45: Incite Lust (Make two targets become lovers)
- 50: Hypnotize (Gain Strong Hook on someone after sleeping with them)
- 60: Alter Personality (Personality change on someone after sleeping with them)
- 70: Sense Secrets (Learn all Secrets of someone after sleeping with them)
- 80: Mindbreak (Massive personality change on someone after sleeping with them)
- 90: Unsoul (Make someone die or become Incapable after sleeping with them)
- 100: Succubus Conversion (Transform human into succubus)

# Per ability:

- Implementation
- Game concept
- Game concept localization
- Add to cdol_ability_tooltips_l_english.yml
- Add to list in "Succubus Mastery" concept
- Add to cdol_ability_unlock_tooltip_effect
- Add to cdol_unlocked_abilities_tooltip_effect

# Credits

* Head textures from [Character Beautification](https://steamcommunity.com/sharedfiles/filedetails/?id=2222302033)
* Trait icon based off pattern 037 from [LewdMarks](https://www.loverslab.com/files/file/9655-lewdmarks/)
* Check Succubus Stats illustration edited from [Succubus 2](https://www.deviantart.com/leevitron/art/Succubus-2-113565769) by [Leevitron](https://www.deviantart.com/leevitron)
* Seal/Unseal Womb illustration edited from [The Fall of Ionia - Irelia](https://www.pixiv.net/en/artworks/73026071) by [Firolian](https://www.pixiv.net/en/users/20223015/)
* Alter Self illustration edited from [Scorched/Marama](https://www.artstation.com/artwork/zAOkqd) by [Nise Loftsteinn](https://www.artstation.com/nise_loftsteinn)
* Regenerate illustration edited from [Blood Succubus](https://www.deviantart.com/cglas/art/Blood-Succubus-520943014) by [CGlas](https://www.deviantart.com/cglas)
* Perform Succubus Transformation Ritual / Awaken Succubus Ancestry illustration edited from [Succubus](https://www.artstation.com/artwork/lVVw15) by [Young June Choi](https://www.artstation.com/gpzang)